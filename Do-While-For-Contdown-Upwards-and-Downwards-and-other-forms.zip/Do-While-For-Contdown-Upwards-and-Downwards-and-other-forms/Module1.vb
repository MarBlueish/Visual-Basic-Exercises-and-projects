﻿Module Module1
    Public var1 As String = "IEFP Gaia"
End Module
