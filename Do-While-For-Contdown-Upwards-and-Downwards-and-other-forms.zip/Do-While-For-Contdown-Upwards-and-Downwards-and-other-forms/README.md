# Do-While-For-Contdown-Upwards-and-Downwards-and-other-forms

This project was made with the orientation of a Visual Basic Teacher and the aid of documentation provided in the class.
For now, there is no navigation provided in the forms that exist but if required will add some in the future.
Please feel free to comment on the project and let me know what you think about it.
